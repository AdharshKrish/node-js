var net = require('net');

var client  = new net.Socket();
client.connect({
  port:2222
});
var JSend = {"id":"17EC116","client":["mcu",null],"data":"connected"};

client.on('connect',function(){
  console.log('Client: connection established with server');

  console.log('---------client details -----------------');
  var address = client.address();
  var port = address.port;
  var family = address.family;
  var ipaddr = address.address;
  console.log('Client is listening at port' + port);
  console.log('Client ip :' + ipaddr);
  console.log('Client is IP4/IP6 : ' + family);

  JSend.client[1]=port;

  client.write(JSON.stringify(JSend));

});

client.setEncoding('utf8');

client.on('data',function(data){
    console.log(data)
});